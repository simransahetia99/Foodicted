package com.example.cardview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button button;

    private CardView firstcard, secondcard, thirdcard, fourthcard, fifthcard, sixthcard;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                openCuisine();
            }
        });
        firstcard = (CardView) findViewById(R.id.one);
        secondcard = (CardView) findViewById(R.id.two);
        thirdcard = (CardView) findViewById(R.id.three);
        fourthcard = (CardView) findViewById(R.id.four);
        fifthcard = (CardView) findViewById(R.id.five);
        sixthcard = (CardView) findViewById(R.id.six);
        //Add click listenner
        firstcard.setOnClickListener(this);
        secondcard.setOnClickListener(this);
        thirdcard.setOnClickListener(this);
        fourthcard.setOnClickListener(this);
        fifthcard.setOnClickListener(this);
        sixthcard.setOnClickListener(this);
    }
    public void openCuisine(){
        Intent intent= new Intent(this, Cuisine.class);
        startActivity(intent);
    }

    @Override
    public void onClick(View v) {
        Intent i;

        switch (v.getId()) {
            case R.id.one:
                i = new Intent(this, one.class);
                startActivity(i);
                break;
            case R.id.two:
                i = new Intent(this, two.class);
                startActivity(i);
                break;
            case R.id.three:
                i = new Intent(this, three.class);
                startActivity(i);
                break;
            case R.id.four:
                i = new Intent(this, four.class);
                startActivity(i);
                break;
            case R.id.five:
                i = new Intent(this, five.class);
                startActivity(i);
                break;
            case R.id.six:
                i = new Intent(this, six.class);
                startActivity(i);
                break;
            default:
                break;

        }
    }
}
